import torch
import torch.nn as nn

class TransformerModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, nhead, num_layers):
        super(TransformerModel, self).__init__()
        self.embedding = nn.Linear(input_size, hidden_size)
        self.transformer_encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=hidden_size, nhead=nhead),
            num_layers=num_layers
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        # Note: Transformer expects input shape (seq_length, batch_size, features)
        x = x.permute(1, 0, 2)
        x = self.embedding(x)
        x = self.transformer_encoder(x)
        x = x.permute(1, 0, 2)
        x = self.fc(x[:, -1, :]) # Take the last step's output
        return x
