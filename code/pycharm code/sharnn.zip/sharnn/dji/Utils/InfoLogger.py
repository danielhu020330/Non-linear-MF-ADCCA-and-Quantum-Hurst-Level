'''
    Copyright:      JarvisLee
    Date:           10/21/2021
    File Name:      InfoLogger.py
    Description:    This file is used to log the information when training the model.
'''

# Import the necessary library.
import os
import logging
from visdom import Visdom
from Utils.ParamsHandler import Handler

# Get the hyperparameters' handler.
Cfg = Handler.Parser(Handler.Generator(paramsDir = './LSTMparams.txt'))

# Set the class to encapsulate the InfoLogger's tools.
class Logger():
    '''
        This class is used to encapsulate all the functions which are used to log the training details.\n
        This class contains five parts:\n
            - VisConfigurator: Used to configurate the visdom server.
            - LogConfigurator: Used to configurate the information logger.
            - VisDrawer: Used to draw the graph in the visdom server.
            - VisSaver: Used to save the visdom graph.
    '''
    # Set the function to configurate the visdom.
    def VisConfigurator(currentTime = None, visName = 'GraphLogging'):
        '''
            This function is used to configurate the visdom.\n
            Params:\n
                - currentTime: Used to indicate each training graph.
                - visName: Used to set the name of the visdom environment.
        '''
        # Create the new visdom environment.
        vis = Visdom(env = visName)
        # Initialize the graphs.
        MSEGraph = vis.line(Y = [0], X = [1], opts = dict(legend = ['TrainMSE', 'EvalMSE'], xlabel = 'Epoch', ylabel = 'MSE', title = f'Train and Eval MSE - {currentTime}'), name = 'TrainMSE')
        MAEGraph = vis.line(Y=[0], X=[1], opts=dict(legend=['TrainMAE', 'EvalMAE'], xlabel='Epoch', ylabel='MAE',title=f'Train and Eval MAE - {currentTime}'), name='TrainMAE')
        R2Graph = vis.line(Y=[0], X=[1], opts=dict(legend=['TrainR2', 'EvalR2'], xlabel='Epoch', ylabel='R2',title=f'Train and Eval R2 - {currentTime}'), name='TrainR2')

        accGraphv1 = vis.line(Y = [0], X = [1], opts = dict(legend = ['TrainAccv1', 'EvalAccv1'], xlabel = 'Epoch', ylabel = 'Acc', title = f'Train and Eval Accs-{Cfg.AccBoundv1} - {currentTime}'), name = 'TrainAccv1')
        accGraphv2 = vis.line(Y = [0], X = [1], opts = dict(legend = ['TrainAccv2', 'EvalAccv2'], xlabel = 'Epoch', ylabel = 'Acc', title = f'Train and Eval Accs-{Cfg.AccBoundv2} - {currentTime}'), name = 'TrainAccv2')
        accGraphv3 = vis.line(Y = [0], X = [1], opts = dict(legend = ['TrainAccv3', 'EvalAccv3'], xlabel = 'Epoch', ylabel = 'Acc', title = f'Train and Eval Accs-{Cfg.AccBoundv3} - {currentTime}'), name = 'TrainAccv3')
        accGraphv4 = vis.line(Y = [0], X = [1], opts = dict(legend = ['TrainAccv4', 'EvalAccv4'], xlabel = 'Epoch', ylabel = 'Acc', title = f'Train and Eval Accs-{Cfg.AccBoundv4} - {currentTime}'), name = 'TrainAccv4')
        vis.line(Y = [0], X = [1], win = MSEGraph, update = 'append', name = 'EvalLoss')
        vis.line(Y=[0], X=[1], win=MAEGraph, update='append', name='EvalLoss')
        vis.line(Y=[0], X=[1], win=R2Graph, update='append', name='EvalLoss')
        vis.line(Y = [0], X = [1], win = accGraphv1, update = 'append', name = 'EvalAccv1')
        vis.line(Y = [0], X = [1], win = accGraphv2, update = 'append', name = 'EvalAccv2')
        vis.line(Y = [0], X = [1], win = accGraphv3, update = 'append', name = 'EvalAccv3')
        vis.line(Y = [0], X = [1], win = accGraphv4, update = 'append', name = 'EvalAccv4')
        # Return the visdom.
        return vis, MSEGraph, MAEGraph, R2Graph, accGraphv1, accGraphv2, accGraphv3, accGraphv4
    
    # Set the function to configrate the logger.
    def LogConfigurator(logDir, filename, format = "%(asctime)s %(levelname)s %(message)s", dateFormat = "%Y-%m-%d %H:%M:%S %p"):
        '''
            This function is used to configurate the logger.\n
            Params:\n
                - logDir: The directory of the logging file.
                - filename: The whole name of the logging file.
                - format: The formate of the logging info.
                - dateFormate: The formate of the date info.
        '''
        # Indicate whether the directory is valid.
        if not os.path.exists(logDir):
            os.mkdir(logDir)
        # Create the logger.
        logger = logging.getLogger()
        # Set the level of the logger.
        logger.setLevel(logging.INFO)
        # Set the logging file.
        file = logging.FileHandler(filename = logDir + '/' + filename, mode = 'a')
        # Set the level of the logging file.
        file.setLevel(logging.INFO)
        # Set the logging console.
        console = logging.StreamHandler()
        # Set the level of the logging console.
        console.setLevel(logging.WARNING)
        # Set the logging format.
        fmt = logging.Formatter(fmt = format, datefmt = dateFormat)
        file.setFormatter(fmt)
        console.setFormatter(fmt)
        # Add the logging file into the logger.
        logger.addHandler(file)
        logger.addHandler(console)
        # Return the logger.
        return logger
    
    # Set the function to draw the graph.
    def VisDrawer(vis, epoch, trainMSE, trainMAE, trainR2, evalMSE, evalMAE, evalR2, trainAccv1, evalAccv1, trainAccv2, evalAccv2, trainAccv3, evalAccv3, trainAccv4, evalAccv4):
        '''
            This function is used to draw the graph in visdom.\n
            Params:\n
                - vis: The tuple contains visdom, lossGraph and accGraph.
                - epoch: The current training epoch.
                - trainLoss: The training loss.
                - evalLoss: The evaluating loss.
                - trainAcc: The training accuracy.
                - evalAcc: The evaluating accuracy.
        '''
        # Inidicate whether the parameters are valid.
        assert type(vis[0]) is type(Visdom()), 'The vis must be the visdom environment.'
        assert type(epoch) is int, 'The epoch must be the integer.'
        # Draw the graph.
        if epoch == 1:
            vis[0].line(Y = [trainMSE], X = [epoch], win = vis[1], name = 'trainMSE', update = 'new')
            if evalMSE != None:
                vis[0].line(Y = [evalMSE], X = [epoch], win = vis[1], name = 'evalMSE', update = 'new')

            vis[0].line(Y=[trainMAE], X=[epoch], win=vis[1], name='trainMAE', update='new')
            if evalMAE != None:
                vis[0].line(Y=[evalMAE], X=[epoch], win=vis[1], name='evalMAE', update='new')

            vis[0].line(Y=[trainR2], X=[epoch], win=vis[1], name='trainR2', update='new')
            if evalR2 != None:
                vis[0].line(Y=[evalR2], X=[epoch], win=vis[1], name='evalR2', update='new')

            vis[0].line(Y = [trainAccv1], X = [epoch], win = vis[2], name = 'TrainAccv1', update = 'new')
            vis[0].line(Y = [trainAccv2], X = [epoch], win = vis[3], name = 'TrainAccv2', update = 'new')
            vis[0].line(Y = [trainAccv3], X = [epoch], win = vis[4], name = 'TrainAccv3', update = 'new')
            vis[0].line(Y = [trainAccv4], X = [epoch], win = vis[5], name = 'TrainAccv4', update = 'new')
            if evalAccv1 != None:
                vis[0].line(Y = [evalAccv1], X = [epoch], win = vis[2], name = 'EvalAccv1', update = 'new')
            if evalAccv2 != None:
                vis[0].line(Y = [evalAccv2], X = [epoch], win = vis[3], name = 'EvalAccv2', update = 'new')
            if evalAccv3 != None:
                vis[0].line(Y = [evalAccv3], X = [epoch], win = vis[4], name = 'EvalAccv3', update = 'new')
            if evalAccv4 != None:
                vis[0].line(Y = [evalAccv4], X = [epoch], win = vis[5], name = 'EvalAccv4', update = 'new')
        else:
            vis[0].line(Y = [trainMSE], X = [epoch], win = vis[1], name = 'trainMSE', update = 'append')
            if evalMSE != None:
                vis[0].line(Y = [evalMSE], X = [epoch], win = vis[1], name = 'evalMSE', update = 'append')

            vis[0].line(Y=[trainMAE], X=[epoch], win=vis[1], name='trainMAE', update='append')
            if evalMAE != None:
                vis[0].line(Y=[evalMAE], X=[epoch], win=vis[1], name='evalMAE', update='append')

            vis[0].line(Y=[trainR2], X=[epoch], win=vis[1], name='trainR2', update='append')
            if evalR2 != None:
                vis[0].line(Y=[evalR2], X=[epoch], win=vis[1], name='evalR2', update='append')


            vis[0].line(Y = [trainAccv1], X = [epoch], win = vis[2], name = 'TrainAccv1', update = 'append')
            vis[0].line(Y = [trainAccv2], X = [epoch], win = vis[3], name = 'TrainAccv2', update = 'append')
            vis[0].line(Y = [trainAccv3], X = [epoch], win = vis[4], name = 'TrainAccv3', update = 'append')
            vis[0].line(Y = [trainAccv4], X = [epoch], win = vis[5], name = 'TrainAccv4', update = 'append')
            if evalAccv1 != None:
                vis[0].line(Y = [evalAccv1], X = [epoch], win = vis[2], name = 'EvalAccv1', update = 'append')
            if evalAccv2 != None:
                vis[0].line(Y = [evalAccv2], X = [epoch], win = vis[3], name = 'EvalAccv2', update = 'append')
            if evalAccv3 != None:
                vis[0].line(Y = [evalAccv3], X = [epoch], win = vis[4], name = 'EvalAccv3', update = 'append')
            if evalAccv4 != None:
                vis[0].line(Y = [evalAccv4], X = [epoch], win = vis[5], name = 'EvalAccv4', update = 'append')
    
    # Set the function to close the visdom server.
    def VisSaver(vis, visName = 'GraphLogging'):
        '''
            This function is used to close the visdom server.\n
            Params:\n
                - visName: Used to set the name of the visdom environment.
        '''
        # Indicate whether the parameters are valid.
        assert type(vis[0]) is type(Visdom()), 'The vis must be the visdom environment.'
        # Save the graph.
        vis[0].save(envs = [visName])

# Test the codes.
if __name__ == "__main__":
    vis = Logger.VisConfigurator('Test', 'Test')
    for each in range(1,101):
        Logger.VisDrawer(vis, each, each + 0.1, 2 * each + 0.2, each + 0.1, 2 * each + 0.2, each + 0.1, 2 * each + 0.2, each + 0.1, 2 * each + 0.2, each + 0.1, 2 * each + 0.2)
    Logger.VisSaver(vis, 'Test')
    logger = Logger.LogConfigurator('./Log', 'Test.txt')
    logger.debug('Test1')
    logger.debug('Test2')
    logger.info('Test3')
    logger.warning('Test4')
    logger.error('Test5')
    logger.exception('Test6')