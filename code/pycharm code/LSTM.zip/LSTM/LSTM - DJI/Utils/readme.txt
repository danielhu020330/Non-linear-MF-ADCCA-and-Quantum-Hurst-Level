NEED:

numpy
matplotlib
pandas
scikit-learn
tqdm
visdom

注意：在开始程序之前，需要在anaconda prompt中输入python -m visdom.server

数据1(dataDir:)
数据1的feature数量(input:)
数据2(dataDir1:)
数据1的feature数量(input1:)

数据nl-qhl(nlqhl)(input=3)
数据raw(nasdaq_raw)(input=1)
数据mf-dfa(nasdaq_mfdfa)(input=1)
数据mf-adcca(nasdaq_mfadcca)(input=2)
数据qpl+mf-dfa(nasdaq_qplmfdfa)(input=1)
数据qpl+mf-adcc(anasdaq_qplmfda)(input=2)

模型输出两组数据的训练效果，并且输出它们mse,mae,r^2的比值

eg.
dataDir:.//Datasets/nlqhl
dataDir1:.//Datasets/nasdaq_raw
input:3
input1:1
输入进LSTM的两组数据分别为nl-qhl和raw

dataDir:.//Datasets/nlqhl
dataDir1:.//Datasets/nasdaq_mfadcca
input:3
input1:2
输入进LSTM的两组数据分别为nl-qhl和mf-adcca