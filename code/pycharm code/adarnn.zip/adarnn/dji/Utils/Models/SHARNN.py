
import torch
import torch.nn as nn
class SingleHeadAttention(nn.Module):
    def __init__(self, hidden_size):
        super(SingleHeadAttention, self).__init__()
        self.hidden_size = hidden_size
        self.attention = nn.Linear(hidden_size, 1, bias=False)
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x):
        # Compute attention scores
        attention_scores = self.attention(x)
        attention_weights = self.softmax(attention_scores)
        # Apply attention weights
        context = torch.sum(attention_weights * x, dim=1)
        return context


class SHARNN(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size):
        super(SHARNN, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.attention = SingleHeadAttention(hidden_size)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size, device=x.device)
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size, device=x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = self.attention(out)
        out = self.fc(out)
        return out
