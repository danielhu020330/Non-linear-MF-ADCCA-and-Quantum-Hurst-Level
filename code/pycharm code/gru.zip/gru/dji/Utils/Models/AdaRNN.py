import torch
import torch.nn as nn
class AdaRNN(nn.Module):

    def __init__(self, input_size, hidden_size, num_layers, output_size, dropout_rate=0.5):
        super(AdaRNN, self).__init__()
        self.hidden_size = hidden_size
        self.num_layers = num_layers
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True, dropout=dropout_rate, bidirectional=False)
        self.fc = nn.Linear(hidden_size, output_size)
        self.adaptive_scale = nn.Parameter(torch.ones(1))  # Adaptive parameter
        self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        h0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size, device=x.device).requires_grad_()
        c0 = torch.zeros(self.num_layers, x.size(0), self.hidden_size, device=x.device).requires_grad_()
        out, (hn, cn) = self.lstm(x, (h0.detach(), c0.detach()))

        # Apply the adaptive scaling to the hidden states
        hn = self.adaptive_scale * hn

        out = self.fc(hn[-1])
        out = self.dropout(out)
        return out

