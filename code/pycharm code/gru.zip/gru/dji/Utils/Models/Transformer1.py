import torch
import torch.nn as nn

def sparse_attention(Q, K, V, block_size=64):
    seq_length = Q.size(-2)
    num_blocks = seq_length // block_size
    output = torch.zeros_like(V)
    for i in range(num_blocks):
        start_idx = i * block_size
        end_idx = (i + 1) * block_size
        Q_block = Q[:, start_idx:end_idx, :]
        K_block = K[:, start_idx:end_idx, :]
        V_block = V[:, start_idx:end_idx, :]
        attn_scores = torch.matmul(Q_block, K_block.transpose(-2, -1)) / (K_block.size(-1) ** 0.5)
        attn_probs = torch.nn.functional.softmax(attn_scores, dim=-1)
        block_output = torch.matmul(attn_probs, V_block)
        output[:, start_idx:end_idx, :] = block_output
    return output

class SparseMultiHeadAttention(nn.Module):
    def __init__(self, embed_size, heads, block_size=64):
        super(SparseMultiHeadAttention, self).__init__()
        self.heads = heads
        self.head_dim = embed_size // heads
        assert self.head_dim * heads == embed_size, "Embedding size must be divisible by number of heads"

        self.values = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.keys = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.queries = nn.Linear(self.head_dim, self.head_dim, bias=False)
        self.fc_out = nn.Linear(heads * self.head_dim, embed_size)
        self.block_size = block_size

    def forward(self, values, keys, query):
        N = query.shape[0]
        value_len, key_len, query_len = values.shape[1], keys.shape[1], query.shape[1]
        values = values.reshape(N, value_len, self.heads, self.head_dim)
        keys = keys.reshape(N, key_len, self.heads, self.head_dim)
        queries = query.reshape(N, query_len, self.heads, self.head_dim)
        output = sparse_attention(queries, keys, values, block_size=self.block_size)
        output = output.reshape(N, query_len, self.heads * self.head_dim)
        output = self.fc_out(output)
        return output

class TransformerModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, nhead, num_layers, block_size=64):
        super(TransformerModel, self).__init__()
        self.embedding = nn.Linear(input_size, hidden_size)
        self.sparse_attention = SparseMultiHeadAttention(hidden_size, nhead, block_size)
        self.transformer_encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=hidden_size, nhead=nhead),
            num_layers=num_layers
        )
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        x = x.permute(1, 0, 2)
        x = self.embedding(x)
        x = self.sparse_attention(x, x, x) # Using sparse attention here
        x = self.transformer_encoder(x)
        x = x.permute(1, 0, 2)
        x = self.fc(x[:, -1, :]) # Take the last step's output
        return x
